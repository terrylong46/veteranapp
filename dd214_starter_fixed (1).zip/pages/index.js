export default function Home() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Welcome to DD214 Update</h1>
      <p>This is your homepage. Use the navigation bar to sign up or log in.</p>
    </div>
  );
}
